# Solaxy Telegram Bot

This bot alerts you on claim windows, sell triggers, and hype tracking.

## How to Deploy
1. Upload to GitHub
2. Click 'Deploy to Render'
3. Add env vars:
   - BOT_TOKEN
   - CHAT_ID
4. Done.